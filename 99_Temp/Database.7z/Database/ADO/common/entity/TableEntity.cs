﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ServiceCore.Database.ADO.common.entity
{
    public abstract class TableEntity : ViewEntity
    {
    }
}
