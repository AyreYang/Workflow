﻿
namespace DataBase.common.interfaces
{
    public interface IConnectionInfo
    {
        string DBConString { get; }
    }
}
